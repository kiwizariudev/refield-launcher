import dearpygui.dearpygui as dpg
import subprocess
import threading
import time
import os
import json
import webbrowser
import random
import sys
import psutil
import socket
import platform
from datetime import datetime

# ================= GLOBAL VARIABLES =================
installation_count = 0
stats_x = []
stats_y = []
already_installed = False
interface_scale = 1.0
banner_texture = None
theme_tag = "futuristic_theme"
current_version = "1.2.5"
latest_version = current_version
update_available = False
user_data = {}
server_status = {"Main Server": "Offline", "EU Server": "Offline", "NA Server": "Offline", "Asia Server": "Offline"}
news_items = []
mods_list = []
active_mods = []
download_progress = 0
download_speed = "0 KB/s"
player_stats = {"play_time": 0, "games_played": 0, "achievements": 0}
game_settings = {"graphics": "High", "sound": 100, "language": "English", "notifications": True}
changelog_content = []
system_info = {}
background_task_running = False
notifications = []
chat_messages = []
friend_list = []
current_channel = "General"
server_players = {"Main Server": 0, "EU Server": 0, "NA Server": 0, "Asia Server": 0}
scheduled_maintenance = {"date": "2025-12-15", "time": "02:00-06:00 UTC", "reason": "Server optimization"}
game_installed_path = ""
game_process = None
ui_color = [50, 150, 255, 255]  # Default blue color

# ================= FILE OPERATIONS =================
def load_user_data():
    global user_data, active_mods, player_stats, game_settings, already_installed, game_installed_path, installation_count, ui_color
    
    try:
        if os.path.exists("user_data.json"):
            with open("user_data.json", "r") as f:
                data = json.load(f)
                user_data = data.get("user_data", {})
                active_mods = data.get("active_mods", [])
                player_stats = data.get("player_stats", player_stats)
                game_settings = data.get("game_settings", game_settings)
                already_installed = data.get("already_installed", False)
                game_installed_path = data.get("game_installed_path", "")
                installation_count = data.get("installation_count", 0)
                ui_color = data.get("ui_color", [50, 150, 255, 255])
    except Exception as e:
        append_log(f"❌ Error loading user data: {str(e)}")

def save_user_data():
    try:
        data = {
            "user_data": user_data,
            "active_mods": active_mods,
            "player_stats": player_stats,
            "game_settings": game_settings,
            "already_installed": already_installed,
            "game_installed_path": game_installed_path,
            "installation_count": installation_count,
            "ui_color": ui_color
        }
        with open("user_data.json", "w") as f:
            json.dump(data, f)
    except Exception as e:
        append_log(f"❌ Error saving user data: {str(e)}")

def load_news():
    global news_items
    # Simulated news loading
    news_items = [
        {"title": "New Update Available!", "date": "2025-11-10", "content": "Version 1.2.5 brings new maps and bug fixes."},
        {"title": "Halloween Event", "date": "2025-10-28", "content": "Special Halloween event with limited-time rewards!"},
        {"title": "Server Maintenance", "date": "2025-10-15", "content": "Scheduled maintenance on October 15th from 2AM to 4AM UTC."},
        {"title": "New DLC Announcement", "date": "2025-10-05", "content": "Expansion pack coming next month with 3 new campaigns."}
    ]

def load_mods():
    global mods_list
    # Simulated mods loading
    mods_list = [
        {"name": "HD Texture Pack", "author": "Modder123", "version": "1.2", "rating": 4.8, "downloads": 12500, "enabled": False},
        {"name": "Ultra Realistic Shaders", "author": "GraphicsGuru", "version": "2.1", "rating": 4.9, "downloads": 18700, "enabled": False},
        {"name": "New Avatar Pack", "author": "AvatarDesigner", "version": "1.0", "rating": 4.5, "downloads": 8900, "enabled": False},
        {"name": "Custom Maps", "author": "Cartographer", "version": "3.4", "rating": 4.7, "downloads": 15600, "enabled": False},
        {"name": "UI Enhancement", "author": "InterfaceMaster", "version": "1.1", "rating": 4.6, "downloads": 11200, "enabled": False}
    ]

def load_changelog():
    global changelog_content
    changelog_content = [
        "Version 1.2.5 (2025-11-10):",
        "- Added new desert map",
        "- Fixed crash on startup issue",
        "- Improved multiplayer connectivity",
        "- Optimized memory usage",
        "",
        "Version 1.2.0 (2025-10-25):",
        "- Added mod support",
        "- New character customization options",
        "- Improved anti-cheat system",
        "- Various bug fixes"
    ]

def load_system_info():
    global system_info
    # Real system information
    try:
        system_info = {
            "Operating System": f"{platform.system()} {platform.release()}",
            "Processor": platform.processor(),
            "CPU Cores": f"{psutil.cpu_count(logical=False)} physical, {psutil.cpu_count(logical=True)} logical",
            "Total RAM": f"{round(psutil.virtual_memory().total / (1024**3), 2)} GB",
            "Available RAM": f"{round(psutil.virtual_memory().available / (1024**3), 2)} GB",
            "Disk Usage": f"{psutil.disk_usage('/').percent}% used",
            "Python Version": platform.python_version(),
            "Hostname": socket.gethostname(),
            "IP Address": socket.gethostbyname(socket.gethostname())
        }
    except Exception as e:
        append_log(f"❌ Error getting system info: {str(e)}")
        system_info = {"Error": "Could not retrieve system information"}

# ================= CALLBACKS =======================
def run_installer(sender, app_data, user_data):
    """Run installation if not installed."""
    global already_installed, installation_count, game_installed_path
    
    def worker():
        global already_installed, installation_count, download_progress, download_speed, game_installed_path
        
        # Check if already installed
        if already_installed:
            response = dpg.get_value("reinstall_confirm")
            if not response:
                add_notification("Please confirm reinstallation", "warning")
                return
                
            append_log("Starting reinstallation...")
        
        set_progress(0, "Preparing installation... 0%")
        
        # Create game directory if it doesn't exist
        game_dir = os.path.join(os.getcwd(), "RefieldGame")
        if not os.path.exists(game_dir):
            os.makedirs(game_dir)
        
        game_installed_path = game_dir
        
        for i in range(101):
            time.sleep(0.02)
            download_progress = i
            download_speed = f"{random.randint(100, 5000)} KB/s"
            set_progress(i, f"Downloading... {i}% ({download_speed})")
            
            if i == 100:
                # Create a simple executable to simulate the game
                if platform.system() == "Windows":
                    exe_path = os.path.join(game_dir, "Refield.exe")
                    with open(exe_path, "w") as f:
                        f.write("echo Refield Game Launched")
                else:
                    exe_path = os.path.join(game_dir, "Refield")
                    with open(exe_path, "w") as f:
                        f.write("#!/bin/bash\necho 'Refield Game Launched'")
                    os.chmod(exe_path, 0o755)
                
                # Create a simple config file
                config_path = os.path.join(game_dir, "config.ini")
                with open(config_path, "w") as f:
                    f.write("[Settings]\nResolution=1920x1080\nFullscreen=1\n")
                
                # Mark as installed
                installation_count += 1
                already_installed = True
                set_progress(100, "✅ Installation completed!")
                append_log("Installation finished successfully.")
                add_notification("Installation completed successfully!", "success")
                
                # Update UI
                dpg.set_item_label("install_btn", "Reinstall Refield")
                dpg.set_item_label("launch_btn", "Launch Game")
                
                # Save user data
                save_user_data()

    threading.Thread(target=worker, daemon=True).start()

def set_progress(value, text):
    dpg.set_value("progress_bar", value / 100.0)
    dpg.set_value("progress_text", text)
    dpg.set_value("download_progress_text", f"Download Progress: {value}%")

def append_log(message):
    current = dpg.get_value("command_output")
    dpg.set_value("command_output", current + message + "\n")
    dpg.set_y_scroll("command_output_window", 100000)

def on_input_text(sender, app_data):
    dpg.set_value("preview_text", f"🔹 Preview: {app_data}")

def on_slider(sender, app_data):
    global interface_scale
    interface_scale = app_data
    dpg.set_value("slider_label", f"Interface Scale: {app_data:.2f}")
    width = int(1000 * interface_scale)
    height = int(720 * interface_scale)
    dpg.configure_item("main_win", width=width, height=height)

def on_combo(sender, app_data):
    dpg.set_value("combo_label", f"Selected mode: {app_data}")
    append_log(f"Launch mode changed to {app_data}")

def on_graphics_setting(sender, app_data):
    game_settings["graphics"] = app_data
    append_log(f"Graphics setting changed to {app_data}")
    save_user_data()

def on_sound_setting(sender, app_data):
    game_settings["sound"] = app_data
    dpg.set_value("sound_value", f"Sound Volume: {app_data}%")
    append_log(f"Sound volume changed to {app_data}%")
    save_user_data()

def on_language_setting(sender, app_data):
    game_settings["language"] = app_data
    append_log(f"Language changed to {app_data}")
    save_user_data()

def on_notification_setting(sender, app_data):
    game_settings["notifications"] = app_data
    status = "enabled" if app_data else "disabled"
    append_log(f"Notifications {status}")
    save_user_data()

def check_for_updates(sender, app_data, user_data):
    global update_available, latest_version
    def update_checker():
        time.sleep(2)  # Simulate update check
        # Randomly decide if update is available (20% chance)
        if random.random() < 0.2:
            latest_version = "1.3.0"
            update_available = True
            add_notification(f"New version {latest_version} available!", "info")
            append_log("Update available! New version: " + latest_version)
            dpg.set_value("update_status", f"Update available: {latest_version}")
        else:
            append_log("No updates available. You have the latest version.")
            dpg.set_value("update_status", "No updates available")
    
    threading.Thread(target=update_checker, daemon=True).start()

def download_update(sender, app_data, user_data):
    if not update_available:
        add_notification("No update available to download", "warning")
        return
        
    def update_downloader():
        global download_progress, download_speed
        for i in range(101):
            time.sleep(0.05)
            download_progress = i
            download_speed = f"{random.randint(500, 5000)} KB/s"
            set_progress(i, f"Downloading update... {i}% ({download_speed})")
            
            if i == 100:
                global current_version
                current_version = latest_version
                append_log("✅ Update downloaded successfully!")
                add_notification("Update downloaded successfully!", "success")
                dpg.set_value("update_status", "Update installed successfully")
                save_user_data()
    
    threading.Thread(target=update_downloader, daemon=True).start()

def launch_game(sender, app_data, user_data):
    global game_process
    
    if not already_installed:
        add_notification("Please install the game first", "error")
        return
        
    append_log("Launching Refield...")
    add_notification("Launching Refield", "info")
    
    try:
        # Try to launch the game executable
        if platform.system() == "Windows":
            exe_path = os.path.join(game_installed_path, "Refield.exe")
            game_process = subprocess.Popen([exe_path])
        else:
            exe_path = os.path.join(game_installed_path, "Refield")
            game_process = subprocess.Popen([exe_path])
            
        append_log("✅ Game launched successfully!")
        add_notification("Game launched successfully!", "success")
        
        # Start play time tracker
        threading.Thread(target=play_time_tracker, daemon=True).start()
    except Exception as e:
        append_log(f"❌ Error launching game: {str(e)}")
        add_notification("Error launching game", "error")

def play_time_tracker():
    start_time = time.time()
    while True:
        time.sleep(1)
        elapsed = int(time.time() - start_time)
        player_stats["play_time"] += 1
        
        # Every 5 minutes, increment games played
        if elapsed % 300 == 0:
            player_stats["games_played"] += 1
            
        # Random chance to unlock achievement
        if random.random() < 0.001:  # 0.1% chance per second
            player_stats["achievements"] += 1
            add_notification("New achievement unlocked!", "success")
        
        # Save every minute
        if elapsed % 60 == 0:
            save_user_data()
            
        # Check if game is still running
        if game_process and game_process.poll() is not None:
            append_log("Game closed")
            add_notification("Game closed", "info")
            break

def toggle_mod(sender, app_data, user_data):
    mod_name = user_data
    if mod_name in active_mods:
        active_mods.remove(mod_name)
        append_log(f"Mod disabled: {mod_name}")
        dpg.set_item_label(sender, "Enable")
    else:
        active_mods.append(mod_name)
        append_log(f"Mod enabled: {mod_name}")
        dpg.set_item_label(sender, "Disable")
    save_user_data()
    update_mods_display()

def update_mods_display():
    # Update the active mods display
    active_mods_text = ", ".join([mod for mod in active_mods if mod is not None]) if active_mods else "No mods active"
    dpg.set_value("active_mods_display", active_mods_text)

def open_website(sender, app_data, user_data):
    webbrowser.open(user_data)

def send_chat_message(sender, app_data, user_data):
    message = dpg.get_value("chat_input")
    if message.strip():
        timestamp = datetime.now().strftime("%H:%M")
        chat_messages.append(f"[{timestamp}] User: {message}")
        dpg.set_value("chat_display", "\n".join(chat_messages[-10:]))
        dpg.set_value("chat_input", "")
        dpg.set_y_scroll("chat_window", 100000)

def change_channel(sender, app_data):
    global current_channel
    current_channel = app_data
    append_log(f"Switched to channel: {app_data}")

def simulate_server_status():
    def status_updater():
        while True:
            time.sleep(30)
            # Randomly change server status
            for server in server_status:
                if random.random() < 0.1:  # 10% chance to change status
                    server_status[server] = "Online" if server_status[server] == "Offline" else "Offline"
                    append_log(f"Server status changed: {server} is now {server_status[server]}")
            
            # Update player counts
            for server in server_players:
                if server_status[server] == "Online":
                    change = random.randint(-50, 100)
                    server_players[server] = max(0, server_players[server] + change)
    
    threading.Thread(target=status_updater, daemon=True).start()

def add_friend(sender, app_data, user_data):
    friend_name = dpg.get_value("friend_name_input")
    if friend_name and friend_name not in friend_list:
        friend_list.append(friend_name)
        dpg.set_value("friends_list", "\n".join(friend_list))
        append_log(f"Added friend: {friend_name}")
        add_notification(f"Added {friend_name} as friend", "success")

def remove_friend(sender, app_data, user_data):
    friend_name = dpg.get_value("friend_name_input")
    if friend_name in friend_list:
        friend_list.remove(friend_name)
        dpg.set_value("friends_list", "\n".join(friend_list))
        append_log(f"Removed friend: {friend_name}")
        add_notification(f"Removed {friend_name} from friends", "info")

def add_notification(message, notif_type="info"):
    timestamp = datetime.now().strftime("%H:%M:%S")
    notification = f"[{timestamp}] {message}"
    notifications.append((notification, notif_type))
    
    # Keep only last 10 notifications
    if len(notifications) > 10:
        notifications.pop(0)
    
    # Update notifications display
    dpg.set_value("notifications_display", "\n".join([n[0] for n in notifications]))

def simulate_background_tasks():
    def task_runner():
        global background_task_running
        background_task_running = True
        while True:
            time.sleep(10)
            # Simulate various background tasks
            if random.random() < 0.3:
                add_notification("Cloud save synchronized", "info")
            
            if random.random() < 0.2:
                player_stats["achievements"] += 1
                add_notification("New achievement unlocked!", "success")
                save_user_data()
    
    threading.Thread(target=task_runner, daemon=True).start()

def verify_game_files(sender, app_data, user_data):
    if not already_installed:
        add_notification("Game is not installed", "error")
        return
        
    append_log("Verifying game files...")
    
    def verification_worker():
        for i in range(101):
            time.sleep(0.02)
            set_progress(i, f"Verifying files... {i}%")
            
            if i == 100:
                # Check if game files exist
                if platform.system() == "Windows":
                    exe_path = os.path.join(game_installed_path, "Refield.exe")
                else:
                    exe_path = os.path.join(game_installed_path, "Refield")
                
                config_path = os.path.join(game_installed_path, "config.ini")
                
                if os.path.exists(exe_path) and os.path.exists(config_path):
                    append_log("✅ All game files verified successfully!")
                    add_notification("Game files verified successfully!", "success")
                    dpg.set_value("verify_status", "All files verified successfully")
                else:
                    append_log("❌ Some game files are missing or corrupted!")
                    add_notification("Game files verification failed!", "error")
                    dpg.set_value("verify_status", "Verification failed - files missing")
    
    threading.Thread(target=verification_worker, daemon=True).start()

def load_updates(sender, app_data, user_data):
    """Load updates from a simulated server"""
    append_log("Checking for updates...")
    
    def update_loader():
        time.sleep(2)  # Simulate network delay
        
        # Simulate update check response
        updates = [
            {"type": "News", "content": "New content update available next week"},
            {"type": "Event", "content": "Double XP weekend starting Friday"},
            {"type": "Maintenance", "content": "Scheduled maintenance on Tuesday at 3AM UTC"}
        ]
        
        for update in updates:
            append_log(f"[{update['type']}] {update['content']}")
        
        append_log("✅ Updates loaded successfully!")
        add_notification("Updates loaded successfully!", "success")
    
    threading.Thread(target=update_loader, daemon=True).start()

def change_ui_color(sender, app_data, user_data):
    global ui_color
    ui_color = app_data[:3] + [255]  # Keep alpha at 255
    update_theme()
    save_user_data()
    append_log(f"UI color changed to {app_data}")

def update_theme():
    with dpg.theme(tag=theme_tag):
        with dpg.theme_component(dpg.mvAll):
            dpg.add_theme_color(dpg.mvThemeCol_WindowBg, (10, 10, 30, 255))
            dpg.add_theme_color(dpg.mvThemeCol_Text, (180, 255, 255, 255))
            dpg.add_theme_color(dpg.mvThemeCol_Button, ui_color)
            dpg.add_theme_color(dpg.mvThemeCol_ButtonHovered, [min(c + 50, 255) for c in ui_color[:3]] + [255])
            dpg.add_theme_color(dpg.mvThemeCol_ButtonActive, [max(c - 30, 0) for c in ui_color[:3]] + [255])
            dpg.add_theme_color(dpg.mvThemeCol_FrameBg, (25, 25, 50, 255))
            dpg.add_theme_color(dpg.mvThemeCol_SliderGrab, (100, 220, 255, 255))
            dpg.add_theme_style(dpg.mvStyleVar_WindowRounding, 12)
            dpg.add_theme_style(dpg.mvStyleVar_FrameRounding, 8)
            dpg.add_theme_style(dpg.mvStyleVar_ItemSpacing, 10, 8)
    
    dpg.bind_theme(theme_tag)

def execute_command(sender, app_data, user_data):
    cmd = dpg.get_value("command_input").strip().lower()
    append_log(f"> {cmd}")
    if cmd == "status":
        append_log(f"Installation status: {'Installed' if already_installed else 'Not installed'}")
        append_log(f"Game version: {current_version}")
        append_log(f"Update available: {'Yes' if update_available else 'No'}")
        append_log(f"Game path: {game_installed_path if game_installed_path else 'Not installed'}")
        append_log(f"Play time: {player_stats['play_time']//3600}h {(player_stats['play_time']%3600)//60}m")
        append_log(f"Games played: {player_stats['games_played']}")
        append_log(f"Achievements: {player_stats['achievements']}/50")
    elif cmd == "reset":
        reset_stats()
    elif cmd == "help":
        append_log("Available commands:\nstatus - check installation\nreset - reset stats\nhelp - show this message\nsimulate - simulate install\nclear - clear console\nloadupdates - load updates from server\ncolor [r] [g] [b] - change UI color")
    elif cmd == "simulate":
        simulate_install()
    elif cmd == "clear":
        dpg.set_value("command_output", "")
    elif cmd == "loadupdates":
        load_updates(None, None, None)
    elif cmd.startswith("color"):
        try:
            parts = cmd.split()
            if len(parts) == 4:
                r = int(parts[1])
                g = int(parts[2])
                b = int(parts[3])
                if 0 <= r <= 255 and 0 <= g <= 255 and 0 <= b <= 255:
                    change_ui_color(None, [r, g, b, 255], None)
                else:
                    append_log("Color values must be between 0 and 255")
            else:
                append_log("Usage: color [r] [g] [b]")
        except ValueError:
            append_log("Invalid color values. Usage: color [r] [g] [b]")
    else:
        append_log(f"Unknown command: {cmd}")

def reset_stats():
    global stats_x, stats_y, installation_count, player_stats
    stats_x = []
    stats_y = []
    installation_count = 0
    player_stats = {"play_time": 0, "games_played": 0, "achievements": 0}
    dpg.set_value("plot_series", [stats_x, stats_y])
    dpg.set_value("stats_label", "👥 0 players installed Refield")
    dpg.set_value("play_time", "Play Time: 0h 0m")
    dpg.set_value("games_played", "Games Played: 0")
    dpg.set_value("achievements", "Achievements: 0/50")
    append_log("Stats reset.")

def simulate_install():
    global installation_count
    installation_count += 1
    stats_x.append(len(stats_x)+1)
    stats_y.append(installation_count)
    dpg.set_value("plot_series", [stats_x, stats_y])
    dpg.set_value("stats_label", f"👥 {installation_count} players installed Refield")
    append_log("Simulated installation.")

# ================= STATS ============================
def update_stats():
    global stats_x, stats_y
    t = 0
    while dpg.is_dearpygui_running():
        time.sleep(1)
        t += 1
        stats_x.append(t)
        stats_y.append(installation_count)
        if len(stats_x) > 50:
            stats_x.pop(0)
            stats_y.pop(0)
        try:
            dpg.set_value("plot_series", [stats_x, stats_y])
            dpg.set_value("stats_label", f"👥 {installation_count} players installed Refield")
        except:
            pass

# ================= GUI =============================
dpg.create_context()

# Load data
load_user_data()
load_news()
load_mods()
load_changelog()
load_system_info()

# Create theme
update_theme()

with dpg.window(label="🚀 Refield Launcher", width=1000, height=720, tag="main_win"):
    # Banner
    if os.path.exists("refield.webp"):
        with dpg.texture_registry(show=False):
            banner_texture = dpg.load_image("refield.webp")
        if banner_texture:
            dpg.add_image(banner_texture, width=950, height=180)
        else:
            dpg.add_text("Could not load refield.webp", color=(255,0,0,255))
    else:
        dpg.add_text("refield.webp not found", color=(255,0,0,255))

    dpg.add_separator()

    # Status bar
    with dpg.group(horizontal=True):
        dpg.add_text("Status: ", color=(100, 255, 100, 255))
        dpg.add_text("Online", tag="status_text", color=(100, 255, 100, 255))
        dpg.add_spacer(width=20)
        dpg.add_text(f"Version: {current_version}", color=(180, 180, 255, 255))
        dpg.add_spacer(width=20)
        dpg.add_text("Players online: 0", tag="online_players", color=(180, 180, 255, 255))

    dpg.add_separator()

    # Tabs
    with dpg.tab_bar():
        # Installation Page
        with dpg.tab(label="Installation"):
            dpg.add_text("Installation", color=(100,220,255,255))
            with dpg.group(horizontal=True):
                dpg.add_button(label="Install Refield", callback=run_installer, width=220, height=40, tag="install_btn")
                dpg.add_button(label="Check for Updates", callback=check_for_updates, width=220, height=40)
                dpg.add_button(label="Download Update", callback=download_update, width=220, height=40)
            
            dpg.add_progress_bar(tag="progress_bar", default_value=0.0, width=-1, height=25)
            dpg.add_text("Waiting...", tag="progress_text", color=(180,255,255,255))
            dpg.add_text("Download Progress: 0%", tag="download_progress_text", color=(180,255,255,255))
            
            dpg.add_separator()
            dpg.add_button(label="Launch Game", callback=launch_game, width=220, height=40, tag="launch_btn")
            
            dpg.add_separator()
            dpg.add_text("Update Status:", color=(100,220,255,255))
            dpg.add_text("Not checked yet", tag="update_status", color=(180,255,255,255))
            
            dpg.add_separator()
            dpg.add_text("Version: 1.2.5", color=(180,255,255,255))
            dpg.add_text("Credits: Kiwizariu", color=(180,255,255,255))
            dpg.add_text("© 2025 Refield Inc.", color=(180,255,255,255))
            
            # Reinstallation confirmation (hidden by default)
            with dpg.group(show=False, tag="reinstall_group"):
                dpg.add_text("Reinstallation will overwrite existing files.", color=(255, 200, 100, 255))
                dpg.add_checkbox(label="I understand and want to continue", tag="reinstall_confirm")
                dpg.add_button(label="Confirm Reinstallation", callback=run_installer)

        # Settings Page
        with dpg.tab(label="Settings"):
            with dpg.child_window(height=300):
                dpg.add_text("Graphics Settings", color=(100,220,255,255))
                dpg.add_combo(label="Graphics Quality", items=["Low", "Medium", "High", "Ultra"], 
                             default_value=game_settings["graphics"], callback=on_graphics_setting)
                
                dpg.add_separator()
                dpg.add_text("Audio Settings", color=(100,220,255,255))
                dpg.add_slider_int(label="Sound Volume", default_value=game_settings["sound"], 
                                  min_value=0, max_value=100, callback=on_sound_setting)
                dpg.add_text(f"Sound Volume: {game_settings['sound']}%", tag="sound_value", color=(180,255,255,255))
                
                dpg.add_separator()
                dpg.add_text("Interface Settings", color=(100,220,255,255))
                dpg.add_slider_float(label="Interface scale", default_value=1.0, min_value=0.5, max_value=2.0, callback=on_slider)
                dpg.add_text("Interface Scale: 1.0", tag="slider_label", color=(180,255,255,255))
                
                dpg.add_combo(label="Language", items=["English", "French", "German", "Spanish", "Japanese"], 
                             default_value=game_settings["language"], callback=on_language_setting)
                
                dpg.add_checkbox(label="Enable Notifications", default_value=game_settings["notifications"], 
                                callback=on_notification_setting)
                
                dpg.add_separator()
                dpg.add_text("UI Color", color=(100,220,255,255))
                dpg.add_color_edit(label="Theme Color", default_value=ui_color, callback=change_ui_color)

        # Stats Page
        with dpg.tab(label="Stats"):
            dpg.add_text("Installation Statistics", color=(100,220,255,255))
            dpg.add_text("👥 0 players installed Refield", tag="stats_label", color=(180,255,255,255))
            with dpg.plot(label="Installation Stats", height=300, width=-1):
                dpg.add_plot_axis(dpg.mvXAxis, label="Time")
                with dpg.plot_axis(dpg.mvYAxis, label="Installations"):
                    dpg.add_line_series(stats_x, stats_y, label="Installations", tag="plot_series")
            
            dpg.add_separator()
            dpg.add_text("Player Statistics", color=(100,220,255,255))
            with dpg.group(horizontal=True):
                dpg.add_text("Play Time: 0h 0m", tag="play_time")
                dpg.add_spacer(width=20)
                dpg.add_text("Games Played: 0", tag="games_played")
                dpg.add_spacer(width=20)
                dpg.add_text("Achievements: 0/50", tag="achievements")

        # Commands Page
        with dpg.tab(label="Console"):
            dpg.add_text("System Console", color=(100,220,255,255))
            dpg.add_input_text(label="Command Input", tag="command_input", width=300, default_value="help")
            dpg.add_button(label="Execute", callback=execute_command)
            dpg.add_button(label="Load Updates", callback=load_updates)
            dpg.add_separator()
            with dpg.child_window(height=300, width=-1, tag="command_output_window", horizontal_scrollbar=True):
                dpg.add_text("", tag="command_output")

        # News Page
        with dpg.tab(label="News"):
            dpg.add_text("Latest News", color=(100,220,255,255))
            for news in news_items:
                with dpg.collapsing_header(label=f"{news['date']} - {news['title']}"):
                    dpg.add_text(news["content"], wrap=800)
            
            dpg.add_separator()
            dpg.add_button(label="Refresh News", callback=load_news)
            dpg.add_button(label="Load Updates", callback=load_updates)

        # Mods Page
        with dpg.tab(label="Mods"):
            dpg.add_text("Available Mods", color=(100,220,255,255))
            for mod in mods_list:
                with dpg.collapsing_header(label=mod["name"]):
                    dpg.add_text(f"Author: {mod['author']}")
                    dpg.add_text(f"Version: {mod['version']}")
                    dpg.add_text(f"Rating: {mod['rating']}/5.0")
                    dpg.add_text(f"Downloads: {mod['downloads']}")
                    btn_label = "Enable" if mod["name"] not in active_mods else "Disable"
                    dpg.add_button(label=btn_label, callback=toggle_mod, user_data=mod["name"])
            
            dpg.add_separator()
            dpg.add_text("Active Mods", color=(100,220,255,255))
            dpg.add_text("No mods active", tag="active_mods_display")

        # Server Status Page
        with dpg.tab(label="Server Status"):
            dpg.add_text("Server Status", color=(100,220,255,255))
            for server, status in server_status.items():
                color = (100, 255, 100, 255) if status == "Online" else (255, 100, 100, 255)
                dpg.add_text(f"{server}: {status} ({server_players[server]} players)", color=color)
            
            dpg.add_separator()
            dpg.add_text("Scheduled Maintenance", color=(100,220,255,255))
            dpg.add_text(f"Date: {scheduled_maintenance['date']}")
            dpg.add_text(f"Time: {scheduled_maintenance['time']}")
            dpg.add_text(f"Reason: {scheduled_maintenance['reason']}")

        # Community Page
        with dpg.tab(label="Community"):
            dpg.add_text("Community Hub", color=(100,220,255,255))
            with dpg.group(horizontal=True):
                dpg.add_button(label="Official Forums", callback=open_website, user_data="https://example.com/forums")
                dpg.add_button(label="Discord", callback=open_website, user_data="https://discord.gg/nUAakPsh")
                dpg.add_button(label="Wiki", callback=open_website, user_data="https://wiki.example.com")
            
            dpg.add_separator()
            dpg.add_text("Friends List", color=(100,220,255,255))
            with dpg.group(horizontal=True):
                dpg.add_input_text(label="Friend Name", tag="friend_name_input", width=200)
                dpg.add_button(label="Add Friend", callback=add_friend)
                dpg.add_button(label="Remove Friend", callback=remove_friend)
            
            dpg.add_text("Friends:", color=(100,220,255,255))
            dpg.add_text("\n".join(friend_list) if friend_list else "No friends added", tag="friends_list")
            
            dpg.add_separator()
            dpg.add_text("Chat", color=(100,220,255,255))
            dpg.add_combo(label="Channel", items=["General", "Help", "Trading"], default_value="General", callback=change_channel)
            with dpg.child_window(height=150, tag="chat_window"):
                dpg.add_text("", tag="chat_display")
            with dpg.group(horizontal=True):
                dpg.add_input_text(label="Message", tag="chat_input", width=300)
                dpg.add_button(label="Send", callback=send_chat_message)

        # System Info Page
        with dpg.tab(label="System Info"):
            dpg.add_text("System Information", color=(100,220,255,255))
            for key, value in system_info.items():
                dpg.add_text(f"{key}: {value}")
            
            dpg.add_separator()
            dpg.add_text("Game Files Integrity", color=(100,220,255,255))
            dpg.add_button(label="Verify Game Files", callback=verify_game_files)
            dpg.add_text("Not verified yet", tag="verify_status", color=(180, 180, 255, 255))
            
            dpg.add_separator()
            dpg.add_text("Changelog", color=(100,220,255,255))
            for line in changelog_content:
                dpg.add_text(line)

        with dpg.tab(label="Notifications"):
            dpg.add_text("Recent Notifications", color=(100,220,255,255))
            dpg.add_text("", tag="notifications_display")


threading.Thread(target=update_stats, daemon=True).start()
threading.Thread(target=simulate_server_status, daemon=True).start()
threading.Thread(target=simulate_background_tasks, daemon=True).start()


add_notification("Launcher started successfully", "success")
add_notification("Connected to update server", "info")
add_notification("Cloud sync enabled", "info")

if already_installed:
    dpg.set_value("progress_text", "✅ Refield is already installed!")
    dpg.set_value("progress_bar", 1.0)
    dpg.set_item_label("install_btn", "Reinstall Refield")
    dpg.set_item_label("launch_btn", "Launch Game")


update_mods_display()

dpg.create_viewport(title="Refield Launcher", width=1000, height=720)
dpg.setup_dearpygui()
dpg.show_viewport()
dpg.start_dearpygui()
dpg.destroy_context()