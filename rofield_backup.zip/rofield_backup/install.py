import time
import sys

def main():
    try:
        for i in range(5):
            print(f"Installation step {i+1}/5...")
            time.sleep(1)  # simule le temps que prend chaque étape
        print("install finished sucess")
        sys.exit(0)  # exit 0 = succès
    except Exception as e:
        print(f"error during install {e}")
        sys.exit(1)  # exit 1 = erreur

if __name__ == "__main__":
    main()